<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreUserRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;


class UserController extends HomeProductController
{
    public function registerForm()
    {
        return view('pages.register',$this->data);
    }

    public function loginForm()
    {
        return view('pages.login',$this->data);
    }

    public function register(StoreUserRequest $request)
    {
        try
        {
            $user = new User();
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = md5($request->password);
            $user->address = $request->address;
            $user->postal_code = $request->postal_code;
            $user->phone = $request->phone;
            $user->city = $request->city;
/*            $image = User::uploadImage($request->image);
            $user->image = $image;*/
            $user->role_id = 2;

            $user->save();

            if(session()->has('user') && session('user')->role_id == 1)
                return redirect()->back()->with('success', 'You successfully registered a user!');
            return redirect()->route('login.create')->with('success', 'You successfully registered, feel free to login!');
        }
        catch (\PDOException $e)
        {
            Log::error($e->getMessage());
            return redirect()->route('register.create')->with('error','There was an error registering your account, please try later!');
        }
    }


    public function login(Request $request)
    {
        $email = $request->email;
        $password = md5($request->password);

        try {
            $user = User::where([
                'email' => $email,
                'password' => $password
            ])->first();

            if($user)
            {
                $request->session()->put('user',$user);
                if($user->role_id == 1)
                    return redirect()->route('admin');
                return redirect()->route('products');
            }

                return redirect()->route('login.create')->with('error','There is no user with these credentials!');

        }
        catch (\PDOException $e)
        {
            Log::error($e->getMessage());
            return redirect()->route('login.create')->with('error','There was an error logging you in, please try later!');
        }
    }

    public function logout()
    {
        session()->remove('user');
        return redirect()->back();
    }
}
