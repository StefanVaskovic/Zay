<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Faker\Provider\Lorem;
use Illuminate\Http\Request;

class HomeController extends HomeProductController
{
    public function __construct(Request $request)
    {
        parent::__construct($request);
        $this->data['slider'] = [
            0 => [
                "title" => "Title 1",
                "subtitle" => "Subtitle 1",
                "description" => $this->faker->text(250),
                "image" => $this->faker->imageUrl()
            ],
            1 => [
                'title' => 'Title 2',
                'subtitle' => 'Subtitle 2',
                'description' => $this->faker->text(250),
                'image' => $this->faker->imageUrl()
            ],
            2 => [
                'title' => 'Title 3',
                'subtitle' => 'Subtitle 3',
                'description' => $this->faker->text(250),
                'image' => $this->faker->imageUrl()
            ]
        ];
        $this->data['products'] = Product::getTopNewestProducts(6);
    }

    public function index()
    {
        //var_dump($request->get("idCat"));
        return view("pages.home",$this->data);
    }
}
