<li><a class="text-decoration-none" href="{{route('products',["idCat"=> $item['idCategory']])}}">{{$item['name']}}</a></li>
