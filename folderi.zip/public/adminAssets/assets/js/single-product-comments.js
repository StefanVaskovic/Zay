
$(document).ready(function (){
    getComments()

})

function getComments() {
    $.ajax({
        url:'/api/comments/'+id,
        method:'get',

        dataType: 'json',
        success: function (data){
            console.log(data)
            printComments(data.product,data.product.comments,data.comments,data.users,data.only_for_checking_if_user_liked_a_comment)
            //printProduct(data.product, data.comments, data.commentDetails)
        },
        error: function (error,xhr,status){
            printErrors(error.responseJSON.errors.text,form)
        }
    });
}

function printComments(product,comments,liked_comments,users,only_for_check) {
    let x=``
    var totalComments = 0
    let i = 0;
    for (const comment of comments) {
        if(comment.pivot.parent_id == null && comment.pivot.user_replied_id == null){
            x+=`
<div class="single-comment-item">
    <div class="sc-author">
        <img src="${comment.image}" alt="${comment.name}">
    </div>
    <div class="sc-text">
        <span>${comment.pivot.date}</span>
        <h5>${comment.name}</h5>
        <p>${comment.pivot.text}</p>
        <span class="text-success font-weight-bold">Number of Likes: ${liked_comments[i].liked_comments.length}</span>

            <a href="#" class="comment-btn reply btn btn-danger float-right" data-idcomment="${comment.pivot.id}"
           data-iduser="${comment.id}" data-form="${i}" data-loggedin=""><i class="fa fa-close"></i></a>

        <form class="replyForm" data-idproduct="${product.id}" data-idcomment="${comment.pivot.id}"
           data-iduser="${comment.id}" data-form="${i}" data-loggedin="">
            <div class="mb-3">
                <textarea class="form-control mt-1" rows="8"></textarea>
            </div>
            <p class="error text-danger"></p>
            <div class="row">
                <div class="col text-end mt-2">
                    <input  class="btn btn-success btn-lg px-3 send" type="button" value="Send"/>
                </div>
            </div>
        </form>
    </div>
</div>
`
            let j = 0;
            for (const c of comments) {
                if(comment.pivot.id == c.pivot.parent_id)
                {
                    x+=`${printSubComments(comment,c,users,liked_comments[j].liked_comments.length,j,only_for_check)}`
                }
                j++
            }

        }


        i++

        totalComments++
    }

    function printSubComments(comment,subComment,users,likes,j,only_for_check) {
        let repliedUser=''

        let x = ``
        repliedUser=findRepliedUser(subComment)
        x+=`<div class="single-comment-item reply-comment">
        <div class="sc-author">
            <img src="${subComment.image}" alt="${subComment.name}">
        </div>
        <div class="sc-text">
            <span>${subComment.pivot.date}</span>
            <h5>${subComment.name}</h5>

            <p><span>@ ${repliedUser!='' ? repliedUser : subComment.name}</span> ${subComment.pivot.text}</p>
            <span class="text-success font-weight-bold">Number of Likes: ${likes}</span>
            <a href="#" class="comment-btn reply btn btn-danger float-right" data-idcomment="${subComment.pivot.parent_id}"
               data-iduser="${subComment.id}" data-form="${j}" data-loggedin=""><i class="fa fa-close"></i></a>
            <form class="replyForm" data-idproduct="${product.id}" data-idcomment="${subComment.pivot.parent_id}"
               data-iduser="${subComment.id}" data-form="${j}" data-loggedin="">
                <div class="mb-3">
                    <textarea name="comment" class="form-control mt-1" rows="8"></textarea>
                </div>
                <p class="error text-danger"></p>
                <div class="row">
                    <div class="col text-end mt-2">
                        <input  class="btn btn-success btn-lg px-3 send" type="button" value="Send"/>
                    </div>
                </div>
            </form>
        </div>
    </div>`

        j++


        return x


        function findRepliedUser(subComment) {
            let repliedUser = ''

            for (const u of users) {
                if(u.id == subComment.pivot.user_replied_id)
                {
                    repliedUser = u.name
                }
            }

            return repliedUser
        }
    }



    function checkIfLikedComment(liked,comment) {
        console.log(liked)
        console.log(comment)
        for (const l of liked) {
            if(l.comment_id == comment.pivot.id && l.userWhoLiked == idUser)
            {
                return  true
            }
        }

        return false
    }

    function checkIfLikedSubComment(liked,subComment) {
        /*console.log(liked)
        console.log(subComment)*/
        for (const l of liked) {
            if(l.comment_id == subComment.pivot.id && l.userWhoLiked == idUser)
            {
                return  true
            }
        }

        return false
    }

    function hasSubComments(comment,comments)
    {
        for (const c of comments) {
            if(comment.pivot.id == c.pivot.id)
            {
                return true
            }
        }
        return false
    }


    function hasLiked(liked_comments,i,idComment)
    {
        if(liked_comments!=null)
        {
            if (liked_comments[i] == undefined)
                return false
            if(liked_comments[i].comment_id == idComment)
                return true
        }

        return false
    }
    function hasLikedSubComment(liked_sub_comments,idSubComment)
    {
        if(liked_sub_comments != null)
        {
            for (const lsc of liked_sub_comments) {
                if(lsc.sub_comment_id == idSubComment)
                    return true
            }
            return  false
        }

        return false
    }

    function isLoggedIn()
    {

    }



    $('#comments').html(x)
    $('#comments').prepend(`<h4>${totalComments} Comments</h4>`)
    $('#numOfComments').html(` ${totalComments}`)
    $('.replyForm').hide();
}
