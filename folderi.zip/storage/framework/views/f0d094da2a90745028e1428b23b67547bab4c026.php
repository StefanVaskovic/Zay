<?php $__env->startSection('content'); ?>
    <h3 class="text-center">Edit product</h3>
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success mt-1"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger mt-1"><?php echo e(session('error')); ?></div>
    <?php endif; ?>
    <form class="col-md-9 m-auto" method="post" role="form" action="<?php echo e(route("products.update",$data['product']->id)); ?>"
          enctype="multipart/form-data">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name">Name</label>
            <input type="text" class="form-control mt-1" id="name" name="name" value="<?php echo e($data['product']->name); ?>"
                   placeholder="Name">
        </div>
        <div class="mb-3">
            <label for="current_price">Price</label>
            <input type="number" class="form-control mt-1" id="current_price" name="current_price"
                   value="<?php echo e($data['product']->current_price); ?>" placeholder="Price">
        </div>
        <div class="mb-3">
            <label for="gender">Gender</label>
            <select id="gender" name="gender" class="form-control mt-1">
                <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($g); ?>" <?php if($data['product']->gender == $g): ?> selected <?php endif; ?>><?php echo e($g); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="color">Color</label>
            <input type="text" class="form-control mt-1" id="color" name="color" value="<?php echo e($data['product']->color); ?>"
            placeholder="Color">
        </div>
        <div class="mb-3">
            <label for="category">Category</label>
            <select id="category" name="category" class="form-control mt-1">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>" <?php if($c->id == $data['product']->category->id): ?> selected <?php endif; ?>
                    ><?php echo e($c->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="brand">Brand</label>
            <select id="brand" name="brand" class="form-control mt-1">
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($b->id); ?>" <?php if($b->id == $data['product']->brand->id): ?> selected
                        <?php endif; ?>><?php echo e($b->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="color">Description</label>
            <textarea class="form-control mt-1" id="description" name="description"
                      placeholder="Description"><?php echo e($data['product']->description); ?></textarea>
        </div>
        <div class="mb-3">
            <label for="color">Sizes</label><br>
            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $data['product']->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($s->id == $size->id): ?>
                <span class="form-check-sign"><?php echo e($s->size); ?></span>
                <input type="number" name="quantitySizes[]" class="form-control" placeholder="quantity"
                       value="<?php echo e($size->pivot->quantity); ?>"/><br>
                        <?php break; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
        </div>
        <div class="row">
            <div class="col text-end mt-2 mb-3">
                <button type="submit" class="btn btn-success btn-fill px-3">Update</button>
            </div>
        </div>
    </form>


    <?php if($errors->any()): ?>
        <div class="alert alert-danger mt-5">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/admin/examples/products/edit.blade.php ENDPATH**/ ?>