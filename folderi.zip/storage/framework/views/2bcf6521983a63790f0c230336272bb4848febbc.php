<script src="<?php echo e(asset('adminAssets/assets/js/core/jquery.3.2.1.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('adminAssets/assets/js/core/popper.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('adminAssets/assets/js/core/bootstrap.min.js')); ?>" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="<?php echo e(asset('adminAssets/assets/js/plugins/bootstrap-switch.js')); ?>"></script>
<!--  Google Maps Plugin    -->

<!--  Chartist Plugin  -->
<script src="<?php echo e(asset('adminAssets/assets/js/plugins/chartist.min.js')); ?>"></script>
<!--  Notifications Plugin    -->
<script src="<?php echo e(asset('adminAssets/assets/js/plugins/bootstrap-notify.jsp')); ?>"></script>
<!-- Control Center for Light Bootstrap Dashboard: scripts for the example pages etc -->
<script src="<?php echo e(asset('adminAssets/assets/js/light-bootstrap-dashboard.js')); ?>?v=2.0.0 " type="text/javascript"></script>
<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
<script src="<?php echo e(asset('adminAssets/assets/js/demo.js')); ?>"></script>


<?php echo $__env->yieldContent("additionalScripts"); ?>

<?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/admin/fixed/scripts.blade.php ENDPATH**/ ?>