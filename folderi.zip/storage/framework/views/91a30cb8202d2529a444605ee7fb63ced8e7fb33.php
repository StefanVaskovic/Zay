<?php $__env->startSection('content'); ?>

    <div class="container py-5">
        <h2 class="text-center">Login</h2>
        <div class="row py-5">

            <form class="col-md-9 m-auto" method="post" role="form" action="<?php echo e(route("login.store")); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="email">Email</label>
                    <input type="email" class="form-control mt-1" id="email" name="email"
                           placeholder="Email">
                </div>
                <div class="mb-3">
                    <label for="password">Password</label>
                    <input type="password" class="form-control mt-1" id="password" name="password"
                           placeholder="Password">
                </div>
                <div class="row">
                    <div class="col text-end mt-2">
                        <button type="submit" class="btn btn-success btn-lg px-3">Login</button>
                    </div>
                </div>
            </form>

            <?php if(request()->session()->has("error")): ?>
                <div class="alert alert-danger col-md-9 m-auto mt-2">
                    <h4><?php echo e(request()->session()->pull("error")); ?></h4>
                </div>
            <?php elseif(request()->session()->has("success")): ?>
                <div class="alert alert-success col-md-9 m-auto mt-2">
                    
                    <h4><?php echo e(request()->session()->pull("success")); ?></h4>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelProject\sajtphp2proba1\resources\views/pages/login.blade.php ENDPATH**/ ?>