<?php $__env->startSection('additionalMeta'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("assets/css/bootstrap.min.css")); ?>">
   
    <link rel="stylesheet" href="<?php echo e(asset("assets/css/custom.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/css/style.css")); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/slick.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/slick-theme.css')); ?>">
<?php echo $__env->yieldSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="bg-light">
        <div class="container pb-5">
            <div class="row" id="product">
                <div class="col-lg-5 mt-5">
                    <div class="card mb-3" id="cover">
                        <img class="card-img img-fluid" src="<?php echo e($data['product']->cover); ?>"
                             alt="<?php echo e($data['product']->name); ?>"
                             id="product-detail">
                    </div>
                    <div class="row">
                        <!--Start Controls-->

                        <div class="col-1 align-self-center">
                            <?php if(count($data['product']->images)/3 > 1): ?>
                                <a href="#multi-item-example" role="button" data-bs-slide="prev">
                                    <i class="text-dark fa fa-chevron-left"></i>
                                    <span class="sr-only">Previous</span>
                                </a>
                            <?php endif; ?>
                        </div>

                        <!--End Controls-->
                        <!--Start Carousel Wrapper-->

                        <div id="multi-item-example" class="col-10 carousel slide carousel-multi-item" data-bs-ride="carousel">
                            <!--Start Slides-->
                            <div class="carousel-inner product-links-wap" role="listbox">

                                <?php for($i = 0; $i < count($data['product']->images)/3; $i++): ?>
                                    <?php echo $__env->make('partials.shop-single.slider',['images'=>$data['product']->images->skip($i * 3)->take(3)
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <?php endfor; ?>

                            </div>

                            <!--End Slides-->
                        </div>

                        <!--End Carousel Wrapper-->
                        <!--Start Controls-->
                        <div class="col-1 align-self-center">
                            <?php if(count($data['product']->images)/3 > 1): ?>
                                <a href="#multi-item-example" role="button" data-bs-slide="next">
                                    <i class="text-dark fa fa-chevron-right"></i>
                                    <span class="sr-only">Next</span>
                                </a>
                            <?php endif; ?>
                        </div>

                        <div class="col-lg-12">
                            <form class="col-md-9 m-auto" method="post" role="form" action="<?php echo e(route("cover.update",
                            $data['product']->id)); ?>"
                                  enctype="multipart/form-data">
                                <?php echo method_field('put'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="file" class="form-control" name="cover" />
                                <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if(session()->has('coverSuccess')): ?>
                                    <div class="alert alert-success mt-1"><?php echo e(session('coverSuccess')); ?></div>
                                <?php endif; ?>
                                <input type="submit" class="form-control btn btn-primary" value="Change Cover">
                            </form>
                            <br>
                            <form class="col-md-9 m-auto" method="post" role="form" action="<?php echo e(route("images.store",$data['product']->id)); ?>"
                                  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="file" multiple class="form-control" name="images[]" />
                                <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php $__errorArgs = ['images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if(session()->has('imagesSuccess')): ?>
                                    <div class="alert alert-success mt-1"><?php echo e(session('imagesSuccess')); ?></div>
                                <?php endif; ?>
                                <input type="submit" class="form-control btn btn-primary" value="Add Images">
                            </form>
                            <br>
                            <form class="col-md-9 m-auto" method="post" role="form" action="<?php echo e(route("images.destroy",$data['product']->id
                            )); ?>"
                                  enctype="multipart/form-data">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <?php if(session()->has('imagesDeletionSuccess')): ?>
                                    <div class="alert alert-success mt-1"><?php echo e(session('imagesDeletionSuccess')); ?></div>
                                <?php endif; ?>
                                <input type="submit" class="form-control btn btn-danger" name="deleteAllImages"
                                       value="Delete
                                All
                                Images"/>
                            </form>
                        </div>
                        <!--End Controls-->
                    </div>
                </div>
                <!-- col end -->
                <div class="col-lg-7 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h1 class="h2"><?php echo e($data['product']->name); ?></h1>
                            <p class="h3 py-2">$<?php echo e($data['product']->current_price); ?></p>
                            <del class="text-center text-danger form-control-sm
                            mb-0"><?php echo e($data['product']->discount_price != null?
                            '$'.$data['product']->discount_price : ''); ?></del>
                            <p class="py-2">
                                Rating:
                                <?php if($data['product']->rate!=0): ?>
                                    <?php for($i = 0;$i<$data['product']->rate;$i++): ?>
                                        <i class="fa fa-star text-warning"></i>
                                    <?php endfor; ?>
                                    <?php for($i = 0;$i<5-$data['product']->rate;$i++): ?>
                                        <i class="fa fa-star text-secondary"></i>
                                    <?php endfor; ?>
                                <?php else: ?>
                                    Not rated yet.
                                <?php endif; ?>
                                <span class="list-inline-item text-dark" >|<span id="numOfComments"></span>
                                    

                                      Comments</span>
                            </p>
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <h6>Brand: </h6>
                                </li>
                                <li class="list-inline-item">
                                    <p class="text-muted"><strong><?php echo e($data['product']->brand->name); ?></strong></p>
                                </li>
                            </ul>
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <h6>Color :</h6>
                                </li>
                                <li class="list-inline-item">
                                    <p class="text-muted"><strong><?php echo e($data['product']->color); ?></strong></p>
                                </li>
                            </ul>
                            <h6>Description:</h6>
                            <p><?php echo e($data['product']->description); ?></p>
                            <form action="<?php echo e(route('products.destroy',$data['product']->id)); ?>" method="POST">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product-title" value="Activewear">
                                <div class="row">
                                    <div class="col-auto">
                                        <ul class="list-inline pb-3">
                                            <li class="list-inline-item">Size :
                                                <input type="hidden" name="product-size" id="product-size" value="S">
                                            </li>
                                            
                                            <?php $__currentLoopData = $data['product']->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($s->pivot->quantity != 0): ?>
                                                    <li class="list-inline-item"><span class="btn btn-success
                                                    btn-size"><?php echo e($s->size); ?></span></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            
                                        </ul>
                                    </div>
                                    <div class="col-auto">
                                        
                                    </div>
                                </div>
                                <div class="row pb-3">
                                    <div class="col d-grid">
                                        <a href="<?php echo e(route('products.edit',$data['product']->id)); ?>" type="submit" class="btn
                                        btn-primary btn-lg" name="submit"
                                                value="buy">Edit</a>
                                    </div>
                                    <div class="col d-grid">
                                        <form action="<?php echo e(route('products.destroy',$data['product']->id)); ?>"
                                              method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger btn-lg" name="submit"
                                                    value="addtocard">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="blog-details-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="blog-details-text">
                        
                        <div class="comment-option" id="comments">

                            



                            

                        </div>

                        
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("additionalScripts"); ?>
    <!-- Start Slider Script -->


    
    <script src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/templatemo.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('adminAssets/assets/js/single-product-comments.js')); ?>"></script>

    <script type="text/javascript">
        const id = '<?php echo e($data['product']->id); ?>';
        const idUser = '<?php echo e(session()->has('user') ? session('user')->id : null); ?>';
    </script>





    <script>
        $('#carousel-related-product').slick({
            infinite: true,
            arrows: false,
            slidesToShow: 4,
            slidesToScroll: 3,
            dots: true,
            responsive: [{
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 3
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 3
                    }
                }
            ]
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/admin/examples/products/single-product.blade.php ENDPATH**/ ?>