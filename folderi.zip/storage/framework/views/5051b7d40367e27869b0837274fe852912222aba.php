



<div class="single-comment-item ">
    <div class="sc-author">
        <img src="<?php echo e($comment->user->image); ?>" alt="">
    </div>
    <div class="sc-text">
        <span><?php echo e($comment->date); ?></span>
        <h5><?php echo e($comment->user->name); ?></h5>
        <p><?php echo e($comment->text); ?></p>
        <a href="#" class="comment-btn like" data-idcomment="<?php echo e($comment->id); ?>"
           data-iduser="<?php echo e($comment->user->id); ?>" data-form="<?php echo e($i); ?>">Like</a>
        <a href="#" class="comment-btn reply" data-idcomment="<?php echo e($comment->id); ?>"
           data-iduser="<?php echo e($comment->user->id); ?>" data-form="<?php echo e($i); ?>">Reply</a>
        <form class="replyForm" data-idproduct="<?php echo e($product->id); ?>" data-idcomment="<?php echo e($comment->id); ?>"
              data-iduser="<?php echo e($comment->user->id); ?>" data-form="<?php echo e($i); ?>">
            <div class="mb-3">
                <textarea class="form-control mt-1" rows="8"></textarea>
            </div>
            <p class="error text-danger"></p>
            <div class="row">
                <div class="col text-end mt-2">
                    <input  class="btn btn-success btn-lg px-3 send" type="button" value="Send"/>
                </div>
            </div>
        </form>
    </div>
    <p>Likes : <?php echo e($comment->likes); ?></p>
</div>

<?php if(count($subComments) != 0): ?>
    <?php $__currentLoopData = $subComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j => $subComment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
        <div class="single-comment-item reply-comment">
            <div class="sc-author">
                <img src="<?php echo e($subComment->image); ?>" alt="">
            </div>
            <div class="sc-text">
                <span><?php echo e($subComment->pivot->date); ?></span>
                <h5><?php echo e($subComment->name); ?></h5>
                <?php ($repliedUser = ""); ?>

                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($u->id == $subComment->pivot->user_replied_id): ?>
                       <?php ( $repliedUser = $u->name); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <p><span>@ <?php echo e(!empty($repliedUser) ? $repliedUser : $subComment->name); ?></span> <?php echo e($subComment->pivot->text); ?></p>
                <a href="#" class="comment-btn like" data-idcomment="<?php echo e($subComment->pivot->comment_id); ?>"
                   data-iduser="<?php echo e($subComment->id); ?>" data-form="<?php echo e($j); ?>">Like</a>
                <a href="#" class="comment-btn reply" data-idcomment="<?php echo e($subComment->pivot->comment_id); ?>"
                   data-iduser="<?php echo e($subComment->id); ?>" data-form="<?php echo e($j); ?>">Reply</a>
                <form class="replyForm" data-idproduct="<?php echo e($product->id); ?>" data-idcomment="<?php echo e($subComment->pivot->comment_id); ?>"
                      data-iduser="<?php echo e($subComment->id); ?>" data-form="<?php echo e($j); ?>">
                    <div class="mb-3">
                        <textarea name="comment" class="form-control mt-1" rows="8"></textarea>
                    </div>
                    <p class="error text-danger"></p>
                    <div class="row">
                        <div class="col text-end mt-2">
                            <input  class="btn btn-success btn-lg px-3 send" type="button" value="Send"/>
                        </div>
                    </div>
                </form>
            </div>
            <p>Likes : <?php echo e($subComment->pivot->likes); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH D:\laravelProject\sajtphp2proba1\resources\views/partials/shop-single/comment.blade.php ENDPATH**/ ?>