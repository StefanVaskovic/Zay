<div class="carousel-item <?php if($i == 0): ?> active <?php endif; ?>">
    <div class="row">
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4">
            <a href="#">
                <img class="card-img img-fluid mb-1" src="<?php echo e($image->image); ?>" alt="Product Image 1">

            </a>
            <?php if(session()->has('user') && session('user')->role_id == 1): ?>
            <form action="<?php echo e(route('image.destroy',$image->id)); ?>" method="post">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger d-block m-auto"><i class="fa fa-times
                fa-xs"></i></button>
            </form>
            <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/partials/shop-single/slider.blade.php ENDPATH**/ ?>