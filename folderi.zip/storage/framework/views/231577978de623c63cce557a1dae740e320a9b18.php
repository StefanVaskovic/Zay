
<div class="single-comment-item <?php if(isset($item->user_replied_id)): ?> reply-comment <?php endif; ?>">
    <div class="sc-author">
        <img src="<?php echo e($user->user->image); ?>" alt="">
    </div>
    <div class="sc-text">
        <span>27 Aug 2019</span>
        <h5><?php echo e($user->user->name); ?></h5>
        <p><?php echo e($item->text); ?></p>
        <a href="#" class="comment-btn like" data-idcomment="<?php echo e(!isset($item->comment_id)?$item->id:$item->comment_id); ?>"
           data-iduser="<?php echo e($user->user->id); ?>" data-form="<?php echo e($i); ?>">Like</a>
        <a href="#" class="comment-btn reply" data-idcomment="<?php echo e(!isset($item->comment_id)?$item->id:$item->comment_id); ?>"
           data-iduser="<?php echo e($user->user->id); ?>" data-form="<?php echo e($i); ?>">Reply</a>
        <form class="replyForm" data-idcomment="<?php echo e(!isset($item->comment_id)?$item->id:$item->comment_id); ?>"
              data-iduser="<?php echo e($user->user->id); ?>" data-form="<?php echo e($i); ?>">
            <div class="mb-3">
                <textarea class="form-control mt-1" rows="8"></textarea>
            </div>
            <div class="row">
                <div class="col text-end mt-2">
                    <input  class="btn btn-success btn-lg px-3" type="button" value="Send" id="send"/>
                </div>
            </div>
        </form>
    </div>
    <p>Likes : <?php echo e($item->likes); ?></p>
</div>
<?php /**PATH C:\xampp\htdocs\vezba_nov_template\resources\views/partials/shop-single/comment.blade.php ENDPATH**/ ?>