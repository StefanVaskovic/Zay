<script src="<?php echo e(asset('assets/js/jquery-1.11.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery-migrate-1.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/templatemo.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

<?php echo $__env->yieldContent("additionalScripts"); ?>
<?php /**PATH C:\xampp\htdocs\vezba_nov_template\resources\views/fixed/scripts.blade.php ENDPATH**/ ?>