<?php $__env->startSection("content"); ?>
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-3">
                <h1 class="h2 pb-4">Categories</h1>
                <ul class="list-unstyled templatemo-accordion" id="categories">
                   
                </ul>
                <h1 class="h2 pb-4">Genders</h1>
                <ul class="list-unstyled templatemo-accordion" id="genders">

                </ul>
                <h1 class="h2 pb-4">Sizes</h1>
                <ul class="list-unstyled templatemo-accordion" id="sizes">

                </ul>
            </div>

            <div class="col-lg-9">
                <div class="row">
                    <div class="col-md-6">
                        
                        <input type="search" class="form-control" placeholder="Search..." id="search"/>
                    </div>
                    <div class="col-md-6 pb-4">
                        <div class="d-flex">
                            <select class="form-control" id="sort">
                                <option value="0">Choose</option>
                                <option value="A-Z">A to Z</option>
                                <option value="Z-A">Z to A</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row" id="products">
                    
                </div>
                <div div="row">
                    <ul class="pagination pagination-lg justify-content-end" id="pages">
                        
                        
                    </ul>
                </div>
            </div>

        </div>
    </div>
    <!-- End Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additionalScripts'); ?>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script type="text/javascript">
        const baseUrl = "<?php echo e(url('/')); ?>";
        const publicFolder = "<?php echo e(asset('/')); ?>";
        const productsShow = baseUrl + "/products";
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/pages/products.blade.php ENDPATH**/ ?>