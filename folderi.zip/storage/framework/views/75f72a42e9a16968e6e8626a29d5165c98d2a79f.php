<?php $__env->startSection('content'); ?>

    <div class="container py-5">
        <h2 class="text-center">Create a new account</h2>
        <div class="row py-5">

            <form class="col-md-9 m-auto" method="post" role="form" action="<?php echo e(route("register.store")); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="form-group col-md-6 mb-3">
                        <label for="name">Name</label>
                        <input type="text" class="form-control mt-1" id="name" name="name" placeholder="Name">
                    </div>
                    <div class="form-group col-md-6 mb-3">
                        <label for="email">Email</label>
                        <input type="email" class="form-control mt-1" id="email" name="email" placeholder="Email">
                    </div>
                </div>
                <div class="mb-3">
                    <label for="password">Password</label>
                    <input type="password" class="form-control mt-1" id="password" name="password"
                           placeholder="Password">
                </div>
                <div class="mb-3">
                    <label for="image">Image</label>
                    <input type="file" class="form-control mt-1" id="image" name="image">
                </div>
                <div class="row">
                    <div class="col text-end mt-2">
                        <button type="submit" class="btn btn-success btn-lg px-3">Register</button>
                    </div>
                </div>
            </form>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger col-md-9 m-auto mt-2">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(request()->session()->has("error")): ?>
                <div class="alert alert-danger col-md-9 m-auto mt-2">
                    <h4><?php echo e(request()->session()->pull("error")); ?></h4>
                </div>
            <?php elseif(request()->session()->has("success")): ?>
                <div class="alert alert-success col-md-9 m-auto mt-2">
                    
                    <h4><?php echo e(request()->session()->pull("success")); ?></h4>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vezba_nov_template\resources\views/pages/register.blade.php ENDPATH**/ ?>