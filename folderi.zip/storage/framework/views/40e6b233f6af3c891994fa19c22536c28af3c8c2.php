<?php if(!session()->has('user')): ?>
    <?php if($item['name'] != 'Logout'): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route($item['route'])); ?>"><?php echo e($item['name']); ?></a>
        </li>
    <?php endif; ?>
<?php else: ?>
    <?php if($item['name'] != 'Register' && $item['name'] != 'Login'): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route($item['route'])); ?>"><?php echo e($item['name']); ?></a>
        </li>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\vezba_nov_template\resources\views/partials/link.blade.php ENDPATH**/ ?>