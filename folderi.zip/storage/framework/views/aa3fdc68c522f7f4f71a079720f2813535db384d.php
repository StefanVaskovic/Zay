            <!-- End Navbar -->


           <?php $__env->startSection('content'); ?>
               <?php if(session()->has('success')): ?>
                   <div class="alert alert-success mt-1"><?php echo e(session('success')); ?></div>
               <?php endif; ?>
               <?php if(session()->has('error')): ?>
                   <div class="alert alert-danger mt-1"><?php echo e(session('error')); ?></div>
               <?php endif; ?>
               <div class="content">
                   <div class="container-fluid">
                       <div class="row">
                           <div class="col-md-12">
                               <div class="card strpied-tabled-with-hover">
                                   <div class="card-header">
                                       <h4 class="card-title">Products</h4>
                                       
                                       <span ><a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary
                                   btn-fill
">Add</a></span>
                                   </div>

                                   <div class="card-body table-full-width table-responsive">

                                       <table class="table table-hover table-striped">
                                           <thead>
                                           <th>ID</th>
                                           <th>Picture</th>
                                           <th>Name</th>
                                           <th>Price</th>
                                           <th>Category Name</th>
                                           </thead>
                                           <tbody>
                                           <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <tr>
                                               <td><?php echo e($p->id); ?></td>
                                               <td><img src="<?php echo e($p->cover); ?>" alt="<?php echo e($p->name); ?>" width="150px"
                                                        height="150px"/></td>
                                               <td><a href="<?php echo e(route('products.show',$p->id)); ?>"><?php echo e($p->name); ?></a></td>
                                               <td>$<?php echo e($p->current_price); ?></td>
                                               <td><?php echo e($p->category->name); ?></td>
                                           </tr>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           </tbody>
                                       </table>
                                   </div>
                               </div>
                               <?php echo e($data['products']->links()); ?>

                           </div>
                       </div>
                   </div>
               </div>
           <?php $__env->stopSection(); ?>
    <!--   -->
    <!-- <div class="fixed-plugin">
    <div class="dropdown show-dropdown">
        <a href="#" data-toggle="dropdown">
            <i class="fa fa-cog fa-2x"> </i>
        </a>

        <ul class="dropdown-menu">
			<li class="header-title"> Sidebar Style</li>
            <li class="adjustments-line">
                <a href="javascript:void(0)" class="switch-trigger">
                    <p>Background Image</p>
                    <label class="switch">
                        <input type="checkbox" data-toggle="switch" checked="" data-on-color="primary" data-off-color="primary"><span class="toggle"></span>
                    </label>
                    <div class="clearfix"></div>
                </a>
            </li>
            <li class="adjustments-line">
                <a href="javascript:void(0)" class="switch-trigger background-color">
                    <p>Filters</p>
                    <div class="pull-right">
                        <span class="badge filter badge-black" data-color="black"></span>
                        <span class="badge filter badge-azure" data-color="azure"></span>
                        <span class="badge filter badge-green" data-color="green"></span>
                        <span class="badge filter badge-orange" data-color="orange"></span>
                        <span class="badge filter badge-red" data-color="red"></span>
                        <span class="badge filter badge-purple active" data-color="purple"></span>
                    </div>
                    <div class="clearfix"></div>
                </a>
            </li>
            <li class="header-title">Sidebar Images</li>

            <li class="active">
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="../assets/img/sidebar-1.jpg" alt="" />
                </a>
            </li>
            <li>
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="../assets/img/sidebar-3.jpg" alt="" />
                </a>
            </li>
            <li>
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="..//assets/img/sidebar-4.jpg" alt="" />
                </a>
            </li>
            <li>
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="../assets/img/sidebar-5.jpg" alt="" />
                </a>
            </li>

            <li class="button-container">
                <div class="">
                    <a href="http://www.creative-tim.com/product/light-bootstrap-dashboard" target="_blank" class="btn btn-info btn-block btn-fill">Download, it's free!</a>
                </div>
            </li>

            <li class="header-title pro-title text-center">Want more components?</li>

            <li class="button-container">
                <div class="">
                    <a href="http://www.creative-tim.com/product/light-bootstrap-dashboard-pro" target="_blank" class="btn btn-warning btn-block btn-fill">Get The PRO Version!</a>
                </div>
            </li>

            <li class="header-title" id="sharrreTitle">Thank you for sharing!</li>

            <li class="button-container">
				<button id="twitter" class="btn btn-social btn-outline btn-twitter btn-round sharrre"><i class="fa fa-twitter"></i> · 256</button>
                <button id="facebook" class="btn btn-social btn-outline btn-facebook btn-round sharrre"><i class="fa fa-facebook-square"></i> · 426</button>
            </li>
        </ul>
    </div>
</div>
 -->

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/admin/examples/products/table.blade.php ENDPATH**/ ?>