<?php $__env->startSection('additionalScripts'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                        <div class="card-body">
                            <h4 class="card-title">Your Profile</h4>
                            <ul class="list-group">
                                <li class="list-group-item">Name: <?php echo e($admin->name); ?></li>
                                <li class="list-group-item">Email: <?php echo e($admin->email); ?></li>
                                <li class="list-group-item">Role: <?php echo e($admin->role->name); ?></li>
                            </ul>
                        </div>
                    </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/admin/examples/profile/edit.blade.php ENDPATH**/ ?>
