<div class="sidebar" data-image="../assets/img/sidebar-5.jpg">
    <!--
Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

Tip 2: you can also add an image using data-image tag
-->
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="http://www.creative-tim.com" class="simple-text">
                Creative Tim
            </a>
        </div>
        <ul class="nav">
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item <?php if(request()->routeIs($m->route)): ?> active <?php endif; ?>">
                    <a class="nav-link" href="<?php echo e(route($m->route)); ?>">
                        <p><?php echo e($m->name); ?></p>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </ul>
    </div>
</div>
<?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/admin/fixed/nav.blade.php ENDPATH**/ ?>