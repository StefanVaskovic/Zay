
<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("fixed.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
<!-- Start Top Nav -->
<?php echo $__env->make("fixed.nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Close Top Nav -->


<!-- Header -->
<?php echo $__env->make("fixed.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Close Header -->

<?php echo $__env->yieldContent("content"); ?>


<!-- Start Footer -->
<?php echo $__env->make("fixed.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Footer -->

<!-- Start Script -->
<?php echo $__env->make("fixed.scripts", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Script -->
</body>

</html>
<?php /**PATH C:\xampp\htdocs\vezba_nov_template\resources\views/layout.blade.php ENDPATH**/ ?>