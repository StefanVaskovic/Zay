<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php if(session()->has('successDelete')): ?>
                        <div class="alert alert-success mt-1"><?php echo e(session('successDelete')); ?></div>
                    <?php endif; ?>
                    <?php if(session()->has('errorDelete')): ?>
                        <div class="alert alert-danger mt-1"><?php echo e(session('errorDelete')); ?></div>
                    <?php endif; ?>
                    <div class="card strpied-tabled-with-hover">
                        <div class="card-header">
                            <h4 class="card-title">Sizes</h4>
                            

                        </div>

                        <div class="card-body table-full-width table-responsive">

                            <table class="table table-hover table-striped">
                                <thead>
                                <th>ID</th>
                                <th>Size</th>
                                <th>Edit</th>
                                <th>Delete</th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($s->id); ?></td>
                                        <td><?php echo e($s->size); ?></td>
                                        <td><a href="<?php echo e(route('sizes.edit',$s->id)); ?>" class="btn btn-primary btn-fill
                                        btn-xs
">Edit</a></td>
                                        <td>
                                            <form action="<?php echo e(route('sizes.destroy',$s->id)); ?>" method="post">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <input type="submit" class="btn btn-danger btn-fill btn-xs" value="Delete" />
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <form class="col-md-9 m-auto" method="post" role="form" action="<?php echo e(route('sizes.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="size">Size</label>
                <input type="text" class="form-control mt-1" id="size" name="size" value=""
                       placeholder="Size">
            </div>
            <?php if(session()->has('successInsert')): ?>
                <div class="alert alert-success mt-1"><?php echo e(session('successInsert')); ?></div>
            <?php endif; ?>
            <?php if(session()->has('errorInsert')): ?>
                <div class="alert alert-danger mt-1"><?php echo e(session('errorInsert')); ?></div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col text-end mt-2 mb-3">
                    <button type="submit" class="btn btn-success btn-fill px-3">Add</button>
                </div>
            </div>
        </form>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/admin/examples/sizes/index.blade.php ENDPATH**/ ?>