<div class="col-12 col-md-4 mb-4">
    <div class="card h-100">
        <a href="<?php echo e(route('product',["id" => $item->id])); ?>">
            <img src="<?php echo e($item->cover); ?>" class="card-img-top" alt="...">
        </a>
        <div class="card-body">
            <ul class="list-unstyled d-flex justify-content-between">
                <li>
                    <?php for($i = 0; $i < 3;$i++): ?>
                        <i class="text-warning fa fa-star"></i>
                    <?php endfor; ?>
                    <?php for($i = 0; $i< 2;$i++): ?>
                        <i class="text-muted fa fa-star"></i>
                    <?php endfor; ?>
                </li>
                <li class="text-muted text-right">$<?php echo e($item->current_price); ?></li>
            </ul>
            <a href="shop-single.html" class="h2 text-decoration-none text-dark"><?php echo e($item->name); ?></a>
            <p class="card-text">
                <?php echo e($item->description); ?>

            </p>
            <p class="text-muted">Reviews (dinamicko)</p>
        </div>
    </div>
</div>
<?php /**PATH D:\laravelProject\sajtphp2proba1\resources\views/partials/home/product.blade.php ENDPATH**/ ?>