            <!-- End Navbar -->

           <?php $__env->startSection('content'); ?>
               <div class="content">
                   <div class="container-fluid">
                       <div class="row">
                           <div class="col-md-12">
                               <div class="card strpied-tabled-with-hover">
                                   <div class="card-header ">
                                       <h4 class="card-title">Striped Table with Hover</h4>
                                       <p class="card-category">Here is a subtitle for this table</p>
                                   </div>
                                   <div class="card-body table-full-width table-responsive">
                                       <table class="table table-hover table-striped">
                                           <thead>
                                           <th>ID</th>
                                           <th>Picture</th>
                                           <th>Name</th>
                                           <th>Price</th>
                                           <th>Category Name</th>
                                           <th>Update</th>
                                           <th>Delete</th>
                                           </thead>
                                           <tbody>
                                           <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <tr>
                                               <td><?php echo e($p->id); ?></td>
                                               <td><img src="<?php echo e($p->cover); ?>" alt="<?php echo e($p->name); ?>" width="150px"
                                                        height="150px"/></td>
                                               <td><?php echo e($p->name); ?></td>
                                               <td>$<?php echo e($p->current_price); ?></td>
                                               <td><?php echo e($p->category->name); ?></td>
                                               <td>
                                                   <button type="button" rel="tooltip" title="Edit Task" class="btn btn-info btn-simple btn-link">
                                                       <i class="fa fa-edit"></i>
                                                   </button>
                                               </td>
                                               <td>
                                                   <button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-simple btn-link">
                                                       <i class="fa fa-times"></i>
                                                   </button>
                                               </td>
                                           </tr>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           
                                           </tbody>
                                       </table>
                                       <?php echo e($data['products']->links()); ?>

                                   </div>
                               </div>
                           </div>
                           <div class="col-md-12">
                               <div class="card card-plain table-plain-bg">
                                   <div class="card-header ">
                                       <h4 class="card-title">Table on Plain Background</h4>
                                       <p class="card-category">Here is a subtitle for this table</p>
                                   </div>
                                   <div class="card-body table-full-width table-responsive">
                                       <table class="table table-hover">
                                           <thead>
                                           <th>ID</th>
                                           <th>Name</th>
                                           <th>Salary</th>
                                           <th>Country</th>
                                           <th>City</th>
                                           </thead>
                                           <tbody>
                                           <tr>
                                               <td>1</td>
                                               <td>Dakota Rice</td>
                                               <td>$36,738</td>
                                               <td>Niger</td>
                                               <td>Oud-Turnhout</td>
                                           </tr>
                                           <tr>
                                               <td>2</td>
                                               <td>Minerva Hooper</td>
                                               <td>$23,789</td>
                                               <td>Curaçao</td>
                                               <td>Sinaai-Waas</td>
                                           </tr>
                                           <tr>
                                               <td>3</td>
                                               <td>Sage Rodriguez</td>
                                               <td>$56,142</td>
                                               <td>Netherlands</td>
                                               <td>Baileux</td>
                                           </tr>
                                           <tr>
                                               <td>4</td>
                                               <td>Philip Chaney</td>
                                               <td>$38,735</td>
                                               <td>Korea, South</td>
                                               <td>Overland Park</td>
                                           </tr>
                                           <tr>
                                               <td>5</td>
                                               <td>Doris Greene</td>
                                               <td>$63,542</td>
                                               <td>Malawi</td>
                                               <td>Feldkirchen in Kärnten</td>
                                           </tr>
                                           <tr>
                                               <td>6</td>
                                               <td>Mason Porter</td>
                                               <td>$78,615</td>
                                               <td>Chile</td>
                                               <td>Gloucester</td>
                                           </tr>
                                           </tbody>
                                       </table>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           <?php $__env->stopSection(); ?>
    <!--   -->
    <!-- <div class="fixed-plugin">
    <div class="dropdown show-dropdown">
        <a href="#" data-toggle="dropdown">
            <i class="fa fa-cog fa-2x"> </i>
        </a>

        <ul class="dropdown-menu">
			<li class="header-title"> Sidebar Style</li>
            <li class="adjustments-line">
                <a href="javascript:void(0)" class="switch-trigger">
                    <p>Background Image</p>
                    <label class="switch">
                        <input type="checkbox" data-toggle="switch" checked="" data-on-color="primary" data-off-color="primary"><span class="toggle"></span>
                    </label>
                    <div class="clearfix"></div>
                </a>
            </li>
            <li class="adjustments-line">
                <a href="javascript:void(0)" class="switch-trigger background-color">
                    <p>Filters</p>
                    <div class="pull-right">
                        <span class="badge filter badge-black" data-color="black"></span>
                        <span class="badge filter badge-azure" data-color="azure"></span>
                        <span class="badge filter badge-green" data-color="green"></span>
                        <span class="badge filter badge-orange" data-color="orange"></span>
                        <span class="badge filter badge-red" data-color="red"></span>
                        <span class="badge filter badge-purple active" data-color="purple"></span>
                    </div>
                    <div class="clearfix"></div>
                </a>
            </li>
            <li class="header-title">Sidebar Images</li>

            <li class="active">
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="../assets/img/sidebar-1.jpg" alt="" />
                </a>
            </li>
            <li>
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="../assets/img/sidebar-3.jpg" alt="" />
                </a>
            </li>
            <li>
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="..//assets/img/sidebar-4.jpg" alt="" />
                </a>
            </li>
            <li>
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="../assets/img/sidebar-5.jpg" alt="" />
                </a>
            </li>

            <li class="button-container">
                <div class="">
                    <a href="http://www.creative-tim.com/product/light-bootstrap-dashboard" target="_blank" class="btn btn-info btn-block btn-fill">Download, it's free!</a>
                </div>
            </li>

            <li class="header-title pro-title text-center">Want more components?</li>

            <li class="button-container">
                <div class="">
                    <a href="http://www.creative-tim.com/product/light-bootstrap-dashboard-pro" target="_blank" class="btn btn-warning btn-block btn-fill">Get The PRO Version!</a>
                </div>
            </li>

            <li class="header-title" id="sharrreTitle">Thank you for sharing!</li>

            <li class="button-container">
				<button id="twitter" class="btn btn-social btn-outline btn-twitter btn-round sharrre"><i class="fa fa-twitter"></i> · 256</button>
                <button id="facebook" class="btn btn-social btn-outline btn-facebook btn-round sharrre"><i class="fa fa-facebook-square"></i> · 426</button>
            </li>
        </ul>
    </div>
</div>
 -->

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelProject\sajtphp2proba1\resources\views/admin/examples/table.blade.php ENDPATH**/ ?>