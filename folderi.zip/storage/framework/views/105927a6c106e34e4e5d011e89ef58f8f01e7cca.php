
        <form class="col-md-9 m-auto" method="post" role="form" action="<?php echo e(route("register.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="form-group col-md-6 mb-3">
                    <label for="name">Name</label>
                    <input type="text" class="form-control mt-1" id="name" name="name" placeholder="Name">
                </div>
                <div class="form-group col-md-6 mb-3">
                    <label for="email">Email</label>
                    <input type="email" class="form-control mt-1" id="email" name="email" placeholder="Email">
                </div>
            </div>
            <div class="mb-3">
                <label for="password">Password</label>
                <input type="password" class="form-control mt-1" id="password" name="password"
                       placeholder="Password">
            </div>
            
            <div class="row">
                <div class="col text-end mt-2">
                    <button type="submit" class="btn btn-success">Register</button>
                </div>
            </div>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger col-md-9 m-auto mt-2">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(request()->session()->has("error")): ?>
                <div class="alert alert-danger col-md-9 m-auto mt-2">
                    <h4><?php echo e(request()->session()->pull("error")); ?></h4>
                </div>
            <?php elseif(request()->session()->has("success")): ?>
                <div class="alert alert-success mt-1"><?php echo e(request()->session()->pull("success")); ?></div>
            <?php endif; ?>
        </form>

<?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/common/register/registerForm.blade.php ENDPATH**/ ?>