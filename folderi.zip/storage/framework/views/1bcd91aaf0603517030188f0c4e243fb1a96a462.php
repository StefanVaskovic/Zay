<div class="carousel-item <?php if($i == 0): ?> active <?php endif; ?>">
    <div class="row">
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4">
            <a href="#">
                <img class="card-img img-fluid" src="<?php echo e($image->image); ?>" alt="Product Image 1">
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\laravelProject\sajtphp2proba1\resources\views/partials/shop-single/slider.blade.php ENDPATH**/ ?>