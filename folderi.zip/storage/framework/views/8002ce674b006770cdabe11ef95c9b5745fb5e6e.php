<?php $__env->startSection("additionalMeta"); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/slick.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/slick-theme.css')); ?>">
<?php echo $__env->yieldSection(); ?>



<?php
    /*$newComments = [];
    $newUsers = [];

      foreach($product->comments as $i => $item){
          if(!in_array($item,$newComments)){

              $newComments[] = $item;
              $newUsers[] = $comments[$i];
          }
          foreach($comments as $com){
              foreach ($com->commentDetails as $cd)
              {

                  if($item->id == $cd->comment_id){
                        $newComments[] = $cd;

                        foreach ($commentDetails as $c)
                        {
                             if($c->id == $cd->user_id){
                                 $newUsers[] = $cd;
                             }

                        }

                    }
              }

          }
    }*/

?>


  <?php $__env->startSection('content'); ?>
      <!-- Open Content -->
      <section class="bg-light">
          <div class="container pb-5">
              <div class="row" id="product">
                  <div class="col-lg-5 mt-5">
                      <div class="card mb-3" id="cover">
                          <img class="card-img img-fluid" src="<?php echo e($product->cover); ?>" alt="<?php echo e($product->name); ?>"
                               id="product-detail">
                      </div>
                      <div class="row">
                          <!--Start Controls-->

                          <div class="col-1 align-self-center">
                              <?php if(count($product->images)/3 > 1): ?>
                              <a href="#multi-item-example" role="button" data-bs-slide="prev">
                                  <i class="text-dark fa fa-chevron-left"></i>
                                  <span class="sr-only">Previous</span>
                              </a>
                              <?php endif; ?>
                          </div>

                          <!--End Controls-->
                          <!--Start Carousel Wrapper-->

                          <div id="multi-item-example" class="col-10 carousel slide carousel-multi-item" data-bs-ride="carousel">
                              <!--Start Slides-->
                              <div class="carousel-inner product-links-wap" role="listbox">

                                  <?php for($i = 0; $i < count($product->images)/3; $i++): ?>
                                        <?php echo $__env->make('partials.shop-single.slider',['images'=>$product->images->skip($i * 3)->take(3)
                                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                  <?php endfor; ?>
                              </div>
                              <!--End Slides-->
                          </div>
                          <!--End Carousel Wrapper-->
                          <!--Start Controls-->
                          <div class="col-1 align-self-center">
                              <?php if(count($product->images)/3 > 1): ?>
                              <a href="#multi-item-example" role="button" data-bs-slide="next">
                                  <i class="text-dark fa fa-chevron-right"></i>
                                  <span class="sr-only">Next</span>
                              </a>
                              <?php endif; ?>
                          </div>

                          <!--End Controls-->
                      </div>
                  </div>
                  <!-- col end -->
                  <div class="col-lg-7 mt-5">
                      <div class="card">
                          <div class="card-body">
                              <h1 class="h2"><?php echo e($product->name); ?></h1>
                              <p class="h3 py-2">$<?php echo e($product->current_price); ?></p>
                              <p class="py-2">
                                  Rating:
                                  <?php if($product->rate!=0): ?>
                                      <?php for($i = 0;$i<$product->rate;$i++): ?>
                                      <i class="fa fa-star text-warning"></i>
                                      <?php endfor; ?>
                                      <?php for($i = 0;$i<5-$product->rate;$i++): ?>
                                          <i class="fa fa-star text-secondary"></i>
                                      <?php endfor; ?>
                                  <?php else: ?>
                                      Not rated yet.
                                  <?php endif; ?>
                                  <span class="list-inline-item text-dark" >|<span id="numOfComments"></span>
                                      
                                      Comments</span>
                              </p>
                              <ul class="list-inline">
                                  <li class="list-inline-item">
                                      <h6>Brand: </h6>
                                  </li>
                                  <li class="list-inline-item">
                                      <p class="text-muted"><strong><?php echo e($product->brand->name); ?></strong></p>
                                  </li>
                              </ul>
                              <ul class="list-inline">
                                  <li class="list-inline-item">
                                      <h6>Color :</h6>
                                  </li>
                                  <li class="list-inline-item">
                                      <p class="text-muted"><strong><?php echo e($product->color); ?></strong></p>
                                  </li>
                              </ul>
                              <h6>Description:</h6>
                              <p><?php echo e($product->description); ?></p>
                              <form action="" method="GET">
                                  <input type="hidden" name="product-title" value="Activewear">
                                  <div class="row">
                                      <div class="col-auto">
                                          <ul class="list-inline pb-3">
                                              <li class="list-inline-item">Size :
                                                  <input type="hidden" name="product-size" id="product-size" value="S">
                                              </li>
                                              <?php $__currentLoopData = $product->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <?php if($s->pivot->quantity != 0): ?>
                                                      <li class="list-inline-item"><span class="btn btn-success
                                                    btn-size"><?php echo e($s->size); ?></span></li>
                                                  <?php endif; ?>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              
                                          </ul>
                                      </div>
                                      <div class="col-auto">
                                          <ul class="list-inline pb-3">
                                              <li class="list-inline-item text-right">
                                                  Quantity
                                                  <input type="hidden" name="product-quanity" id="product-quanity" value="1">
                                              </li>
                                              <li class="list-inline-item"><span class="btn btn-success" id="btn-minus">-</span></li>
                                              <li class="list-inline-item"><span class="badge bg-secondary" id="var-value">1</span></li>
                                              <li class="list-inline-item"><span class="btn btn-success" id="btn-plus">+</span></li>
                                          </ul>
                                      </div>
                                  </div>
                                  <div class="row pb-3">
                                      <div class="col d-grid">
                                          <button type="submit" class="btn btn-success btn-lg" name="submit" value="buy">Buy</button>
                                      </div>
                                      <div class="col d-grid">
                                          <button type="submit" class="btn btn-success btn-lg" name="submit" value="addtocard">Add To Cart</button>
                                      </div>
                                  </div>
                              </form>

                          </div>
                      </div>



                  </div>
              </div>
          </div>
      </section>
      <!-- Close Content -->
      <!-- Blog Details Section Begin -->
      <section class="blog-details-section">
          <div class="container">
              <div class="row">
                  <div class="col-lg-10 offset-lg-1">
                      <div class="blog-details-text">
                          
                          <div class="comment-option" id="comments">

                              

                          </div>

                          <div class="leave-comment">
                              <h4>Leave A Comment</h4>
                              <form class="comment-form">
                                  <div class="row">
                                      <div class="col-lg-12 text-center">
                                          <textarea placeholder="Messages"></textarea>
                                          <p class="error text-danger"></p>
                                          <button type="button" id="btnMainComment" class="site-btn">Send
                                              Message</button>
                                      </div>
                                  </div>
                              </form>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <!-- Blog Details Section End -->
  <?php $__env->stopSection(); ?>

<?php $__env->startSection("additionalScripts"); ?>
    <!-- Start Slider Script -->
    <script type="text/javascript">
        const id = '<?php echo e($product->id); ?>';
        const idUser = '<?php echo e(session()->has('user') ? session('user')->id : ''); ?>';
        console.log(idUser)
    </script>

    <script src="<?php echo e(asset('assets/js/shop-single.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>


    <script>
        $('#carousel-related-product').slick({
            infinite: true,
            arrows: false,
            slidesToShow: 4,
            slidesToScroll: 3,
            dots: true,
            responsive: [{
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 3
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 3
                    }
                }
            ]
        });
    </script>
    <!-- End Slider Script -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/pages/shop-single.blade.php ENDPATH**/ ?>