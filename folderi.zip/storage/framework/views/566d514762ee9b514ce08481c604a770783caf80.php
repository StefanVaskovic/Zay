<meta charset="utf-8" />
<link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('adminAssets/assets/img/apple-icon.png')); ?>">
<link rel="icon" type="image/png" href="<?php echo e(asset('adminAssets/assets/img/favicon.ico')); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>
    Paper Dashboard 2 by Creative Tim
</title>
<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
<!--     Fonts and icons     -->
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
<!-- CSS Files -->
<link href="<?php echo e(asset('adminAssets/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('adminAssets/assets/css/light-bootstrap-dashboard.css')); ?>" rel="stylesheet" />
<!-- CSS Just for demo purpose, don't include it in your project -->
<link href="<?php echo e(asset('adminAssets/assets/css/demo.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('adminAssets/assets/css/style.css')); ?>" rel="stylesheet" />
<?php echo $__env->yieldContent('additionalMeta'); ?>



<?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/admin/fixed/head.blade.php ENDPATH**/ ?>