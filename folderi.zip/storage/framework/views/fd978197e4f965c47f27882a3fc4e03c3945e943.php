<?php $__env->startSection('content'); ?>
    <div class="content">
    <form class="col-md-9 m-auto" method="post" role="form" action="<?php echo e(route('categories.update',$category->id)); ?>">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name">Name</label>
            <input type="text" class="form-control mt-1" id="name" name="name" value="<?php echo e($category->name); ?>"
                   placeholder="Name">
        </div>
        <?php if(session()->has('successUpdate')): ?>
            <div class="alert alert-success mt-1"><?php echo e(session('successUpdate')); ?></div>
        <?php endif; ?>
        <?php if(session()->has('errorUpdate')): ?>
            <div class="alert alert-danger mt-1"><?php echo e(session('errorUpdate')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col text-end mt-2 mb-3">
                <button type="submit" class="btn btn-success btn-fill px-3">Update</button>
            </div>
        </div>
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/admin/examples/categories/edit.blade.php ENDPATH**/ ?>