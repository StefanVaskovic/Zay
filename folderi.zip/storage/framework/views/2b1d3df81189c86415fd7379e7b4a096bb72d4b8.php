
<?php if($i == 0): ?>
<div class="carousel-item active">
    <div class="container">
        <div class="row p-5">
            <div class="mx-auto col-md-8 col-lg-6 order-lg-last">
                <img class="img-fluid" src="<?php echo e($item['image']); ?>" alt="">
            </div>
            <div class="col-lg-6 mb-0 d-flex align-items-center">
                <div class="text-align-left align-self-center">
                    <h1 class="h1 text-success"><?php echo e($item['title']); ?></h1>
                    <h3 class="h2"><?php echo e($item['subtitle']); ?></h3>
                    <p>
                        <?php echo e($item['description']); ?>

                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="carousel-item">
    <div class="container">
        <div class="row p-5">
            <div class="mx-auto col-md-8 col-lg-6 order-lg-last">
                <img class="img-fluid" src="<?php echo e($item['image']); ?>" alt="">
            </div>
            <div class="col-lg-6 mb-0 d-flex align-items-center">
                <div class="text-align-left">
                    <h1 class="h1"><?php echo e($item['title']); ?></h1>
                    <h3 class="h2"><?php echo e($item['subtitle']); ?></h3>
                    <p>
                        <?php echo e($item['description']); ?>

                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH D:\laravelProject\sajtphp2proba3\resources\views/partials/home/carousel.blade.php ENDPATH**/ ?>